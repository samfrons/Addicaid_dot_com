'use strict';

angular.module('addicaidSiteApp')
  .controller('InspirationCtrl', ['$scope', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  }]);
