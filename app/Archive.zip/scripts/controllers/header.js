'use strict';

angular.module('addicaidSiteApp')
  .controller('HeaderCtrl', ['$scope', function ($scopesu) {


  }]);
