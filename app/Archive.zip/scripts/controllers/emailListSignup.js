'use strict';

angular.module('addicaidSiteApp')
  .controller('EmailListSignupCtrl', ['$scope', function ($scope) {
  }]);
