'use strict';

angular.module('addicaidSiteApp')
  .controller('HeadlineCtrl', ['$scope', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  }]);
