'use strict';

angular.module('addicaidSiteApp')
  .controller('MapCtrl', ['$scope', function ($scope) {
  }]);
